//-----------------------------------------------------------------------------------/
//  phpQuickArcade v3.0.23 � Jcink 2005-2010 quickarcade.jcink.com                        
//
//  Version: 3.0.23 Final. Released: 3:20 AM 5/2/2010
//-----------------------------------------------------------------------------------/
// Thanks to (Sean) http://seanj.jcink.com 
// for: Tournies, JS, and more
// ---------------------------------------------------------------------------------
//
//  IF YOU HAVE NOT READ, AGREED TO, AND UNDERSTOOD THE 
//  LICENSE AGREEMENT, YOU MAY NOT USE THIS SOFTWARE.
//
//==========================================================
!
! THIS SOFTWARE IS NOT OPEN SOURCE! 
!
! YOU MAY NOT REDISTRIBUTE IT! YOU MAY MODIFY IT, BUT for ONLY your OWN USE AND
! UNDER THE OTHER TERMS OF THIS LICENSE! 
!
! BUT YOU MAY NOT REMOVE OR OBSTRUCT THE COPYRIGHT!
!
! THIS PROGRAM IS DISTRIBUTED FREE OF CHARGE, AND 
! COMES WITH NO WARRANTY. BY USING THIS SCRIPT, 
! YOU AGREE THAT YOU USE THIS PROGRAM AT YOUR OWN 
! RISK. I AM NOT RESPONSIBLE FOR ANYTHING THAT OCCURS 
! THROUGH YOUR USE OF THE SCRIPT. This script is distributed "AS IS."
!
!  YOU (the "downloader" ) MAY NOT REDISTRIBUTE,
!  SELL, OR TRADE THIS PROGRAM WITHOUT PRIOR PERMISSION FROM THE AUTHOR.
!
! YOU MAY MODIFY, AND SHARE HOW YOU DID MODIFICATIONS WITH OTHERS. THE FILES ARE NOT TO  ! SHARED UNDER ANY ! CIRCUMSTANCES.
!
! YOU MAY NOT REMOVE OR OBSTRUCT THE COPYRIGHT.
!
! YOU MAY NOT REDISTRIBUTE THE PHP FILES UNDER ANY CIRCUMSTANCE.
!
! -=-=-=-=-==-=-=--==--==-=-=-=-=-=-=-=-=--=-=-=-=-==-=-=-=-=-=-=-=-=-
! GAMES (C) RESPECTED OWNERS.
! THEY ARE NOT MY GAMES.
!
! WHERE TO GET INFORMATION ABOUT DISTRIBUTION OF GAMES:
! Neave Games presented By: http://www.neave.com/games/
! (Copyright information on Neave Games : ! http://www.neave.com/games/help/copyright.php ) 
!
! Flasteroids Presented By: http://www.bodekaer.dk/ was "Free for use" when
! I downloaded the .fla!
! -=-=-=-=-==-=-=--==--==-=-=-=-=-=-=-=-=--=-=-=-=-==-=-=-=-=-=-=-=-=-