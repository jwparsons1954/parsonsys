<?php
$place = htmlspecialchars($_GET['cparea']); 
if ($_REQUEST['acpcheck']) die();
if ($_COOKIE['acpcheck']) die();
if ($acpcheck !="ok") die("You cannot access this area directly.");

if($place == "idx") {
?><br />
<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='left' colspan=9><b><font size=-5>Add New Games</font></b></td></tr><td class='arcade1' align='left'>Add new games to your arcade using a variety of methods.<br><br>[ <a href=Arcade.php?cparea=addgames>Add Games</a> ]</div></td></table></div>
<br />
<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='left' colspan=9><b><font size=-5>Edit/Create Cats</font></b></td></tr><td class='arcade1' align='left'>Manage Arcade categories.<br><br>[ <a href=Arcade.php?cparea=cats>Manage</a> ]</div></td></table></div>
<br />
<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='left' colspan=9><b><font size=-5>Skin Control</font></b></td></tr><td class='arcade1' align='left'>Create new skin files, edit, and delete.<br><br>[ <a href=Arcade.php?cparea=skin>Manage</a> ]</div></td></table></div>
<br />
<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='left' colspan=9><b><font size=-5>Games manager</font></b></td></tr><td class='arcade1' align='left'>Sort, delete and edit existing games in your arcade's library.<br><br>[ <a href='Arcade.php?cparea=games'>Manage</a> ]</div></td></table></div>
<br />
<div class='tableborder'><table width=100%% cellpadding='5' cellspacing='1'><tr><td class=headertableblock colspan=9 align='left'><b><font size=-5>Emoticons</font></b></td></tr><td class=arcade1 align='left'>Add smilies to your arcade. To make the smiley images appear in the dropdown, upload them to the emoticons folder.<br><br>[ <a href='Arcade.php?cparea=emotes'>Manage</a> ]</div></td></table></div>
<br />
<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='left' colspan=9><b><font size=-5>MySQL Toolbox</font></b></td></tr><td class='arcade1' align='left'>Backup, restore, repair, and optimize your databse.<br><br>[ <a href=Arcade.php?cparea=mysql>Manager</a> ]</div></td></table></div>
<br />
<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='left' colspan=9><b><font size=-5>Member Editor</font></b></td></tr><td class='arcade1' align='left'>Edit members. Avatar, and profile info, erase members... also get IP address on date of registration, make moderators and admins, etc. 
<br><br>[ <a href=Arcade.php?cparea=members>Manager</a> ] [ <a href='?cparea=members&act=Validating'>Validating Users</a> ]</div></td></table></div>
<br />
<div align='center'><div class='tableborder'><table width=100%% cellpadding='5' cellspacing='1'><tr><td class=headertableblock colspan=9><b><font size=-5>Banned IP addresses</font></b></td></tr><td class=arcade1>Banned IP address list.<br><br>[ <a href='?cparea=bannedIPlist'>Manage</a> ]</div></td></table></div>
<br />
<!-- 

06/01/09

What can I say? This is a stupid section that was never fully finished; and there's never going to be a way to protect these games.
Cheat protection is a joke; http_referer is so easily faked it's not even funny. It's just not worth having. As long as the games
can be decompiled, and http is as 'vulnerable' as it is, it cannot be beat 100%, and certainly not in a platform like this. Maybe
at some point in the future this will change, but not for now.

<div align='center'><div class='tableborder'><table width=100%% cellpadding='5' cellspacing='1'><tr><td class=headertableblock colspan=9><b><font size=-5>Blocked Cheating Attempts</font></b></td></tr><td class=arcade1>Check logs for cheating.<br><br>[ <a href='?cparea=Cheating_Attempts'>Manage</a> ]</div></td></table></div>
<br /> 

-->
<div align='center'><div class='tableborder'><table width=100%% cellpadding='5' cellspacing='1'><tr><td class=headertableblock colspan=9><b><font size=-5>Settings</font></b></td></tr><td class=arcade1>Edit your arcade's settings. Enable validation, enable shoutbox, disable features etc <br><br>[ <a href='?cparea=settings'>Manage</a> ]</div></td></table></div>
<br />
<div align='center'><div class='tableborder'><table width=100%% cellpadding='5' cellspacing='1'><tr><td class=headertableblock colspan=9><b><font size=-5>Post Office</font></b></td></tr><td class=arcade1>Send an email to all members. Note: requires hosting to have the mail(); feature on.<br><br>[ <a href='?cparea=Email'>Manage</a> ]</div></td></table></div>
<br />
<div align='center'><div class='tableborder'><table width=100%% cellpadding='5' cellspacing='1'><tr><td class=headertableblock colspan=9><b><font size=-5>Word Filters</font></b></td></tr><td class=arcade1>Modify badword filters.<br><br>[ <a href='?cparea=filter'>Manage</a> ]</div></td></table></div>
<br />
<?php
} elseif ($place == "addgames") {


// The different methods
if (!$_GET['method']) {
?>


<div class='tableborder' align='left'><table width=100% cellpadding='4' cellspacing='1'><td width='20%' align='center' class='headertableblock' colspan='2'>Adding a new game - Click on a method</td><tr>

<tr><td class='arcade1' align='left'><b><A href='Arcade.php?cparea=addgames&method=upload'>Upload Method</b><br></td><td class='arcade1'>Attach the game files using upload from your browser.</td></tr>

<tr><td class='arcade1' align='left'><b><A href='Arcade.php?cparea=addgames&method=ftp'>FTP Method</b><br></td><td class='arcade1'>Use this method if you have uploaded the game files with "FTP" and now want to add the game.</td></tr>

<tr><td class='arcade1' align='left'><b><A href='Arcade.php?cparea=addgames&method=server'>Server Method</b><br></td><td class='arcade1'>Put in a URL to a game, and let the arcade place it on your server for you.</td></tr>

<tr><td class='arcade1' align='left'><b><A href='Arcade.php?cparea=addgames&method=hotlink'>Remote Method</b><br></td><td class='arcade1'>Hotlink the game from a remote site.</td></tr>

<tr><td class='arcade1' align='left'><b><A href='Arcade.php?cparea=tar_import'>Tar Method</b><br></td><td class='arcade1'>Add games using IbProArcade tars.</td></tr>

</div>

 </td>
</table>
</div>
<br>
<?php
} elseif($_GET['method'])  {

	// ===============================================================
	// 
	//     ************* Adder Queries and Stuff *****************
	//
	// ===============================================================

if($_POST['addgame']) {
vsess();

$swf = $_POST['swf'];
$gif = $_POST['gif'];
$game = $_GET['game'];

if ($_POST['gamename']) { 
// if they posted a game name make it take the info from the.
// input rather than the importer file.

$gamename = htmlspecialchars($_POST['gamename'], ENT_QUOTES);
$idname = htmlspecialchars($_POST['idname'], ENT_QUOTES);
$gameheight = htmlspecialchars($_POST['height'], ENT_QUOTES);
$gamewidth = htmlspecialchars($_POST['width'], ENT_QUOTES);
$about = htmlspecialchars($_POST['desc'], ENT_QUOTES);
$gamecat = htmlspecialchars($_POST['gamecat'], ENT_QUOTES);

} else { // If gamename wasn't posted, then do the importer stuff.

$uploadphp = move_uploaded_file($_FILES['php']['tmp_name'], "./imports/".$_FILES['php']['name']) ;

if ($uploadphp) { 
// Did the upload fail? If not require in that importer file.

require("./imports/".$_FILES['php']['name']);

$gamename = $game_name;
$about = $game_desc;
$gameheight = $game_height;
$gamewidth = $game_width;
$idname = $game_IDNAME;
$gamecat = htmlspecialchars($_POST['gamecat'], ENT_QUOTES);

unlink("./imports/".$_FILES['php']['name']);

} else { 
// Failure, display message.

message("The Importer file failed to upload. Check to make sure the imports folder is CHMOD 777.");

}



}

// Method check
 
$remoteurl = '';

if ($_GET['method']=="upload") {

//==================================
// Uploadable method
//==================================

$gifsend = @move_uploaded_file($_FILES['uploadgif']['tmp_name'], "./arcade/pics/".$_FILES['uploadgif']['name']) ;
$swfsend = @move_uploaded_file($_FILES['uploadswf']['tmp_name'], "./arcade/".$_FILES['uploadswf']['name']);
if ($swfsend) { $swf_ok = "Yes"; } 
else { message("The SWF file failed to upload. Make sure the arcade folder <a href=\"arcade/\" target='_new'>exists</a> and is CHMOD 777."); 
}

if ($gifsend) {
$gif_ok = "Yes"; 
} else { 
message("The GIF file failed to upload. Make sure the pics folder <a href=\"arcade/pics\" target='_new'>exists</a> and is CHMOD 777."); 
}

}

//==================================
// End uploadable method , start FTP
//==================================

if ($_GET['method']=="ftp") {
$swf_ok = "Yes";
$gif_ok = "Yes";
}

//==================================
// End FTP method , start server
//==================================

if ($_GET['method']=="server") {
$swfbinary = @file_get_contents($swf);

if ($swfbinary) {
$swf_file = @fopen("./arcade/$idname.swf", "a");
if ($swf_file) {
@fwrite($swf_file, $swfbinary);
@fclose($swf_file);
$swf_ok = "Yes";
$found_swf = "Yes";
} else {
message("The swf file couldnt be copied to your server. Please check that the /arcade/ folder exists and is CHMOD 777");
}

} else {
message("The server you tried to contact to get the SWF file could not be reached. It could be down, or your host has disabled this method of uploading");
}


$gifbinary = @file_get_contents($gif);

if ($gifbinary) {
$gif_file = @fopen("./arcade/pics/$idname.gif", "a");
if ($gif_file) {
@fwrite($gif_file, $gifbinary);
@fclose($gif_file);
$gif_ok = "Yes";
} else {
message("The gif file couldnt be copied to your server. Please check that the /arcade/pics/ folder exists and is CHMOD 777");
}

} else {
message("The server you tried to contact to get the GIF file could not be reached. It could be down, or your host has disabled this method of uploading");
}

}


//==================================
// End server method , start remote method
//==================================

if ($_GET['method']=="hotlink") {
$swf_ok = "Yes";
$remoteurl = $swf;

$gifsend = @move_uploaded_file($_FILES['uploadgif']['tmp_name'], "./arcade/pics/".$_FILES['uploadgif']['name']) ;

if ($gifsend) {
$gif_ok = "Yes"; 
} else { 
message("The GIF file failed to upload. Make sure the pics folder <a href=\"arcade/pics\" target='_new'>exists</a> and is CHMOD 777."); 
}


}

// ============================
// Start Edit
// ============================
$champ='';
$champs='';
if ($_GET['method']=="edit") {
$editgame = mysql_fetch_array(run_query("SELECT * FROM phpqa_games WHERE gameid='$idname'"));
$champ=$editgame[Champion_name];
$champs=$editgame[Champion_score];

run_query("DELETE FROM phpqa_games WHERE gameid='$game'");
$remoteurl = $swf;
$swf_ok = 'Yes';
$gif_ok = 'Yes';
$found_swf = 'Yes';
}

if ($remoteurl == "") {

if (file_exists("./arcade/$idname.swf")) { 
$found_swf = "Yes";
} else { 
message("The .swf file couldn't be found. You may have uploaded it successfully, but got the games idname wrong."); 
}

} else {
$found_swf = "Yes";
}

if ($gif_ok == "Yes" && $swf_ok == "Yes" && $found_swf == "Yes") {


$idname = htmlspecialchars($idname, ENT_QUOTES);
$addedalready = mysql_fetch_array(run_query("SELECT * FROM phpqa_games WHERE gameid='$idname'"));


if (!$addedalready) {
message("Game added/edited. <br>[ <a href='Arcade.php?cparea=idx'>Arcade CP Home</a> | <a href='Arcade.php?cparea=addgames&method=".$_GET['method']."'>Add Another</a> ]");
run_query("INSERT INTO phpqa_games (game,gameid,gameheight,gamewidth,about,gamecat,remotelink,Champion_name,Champion_score,times_played) VALUES ('$gamename','$idname','$gameheight','$gamewidth','$about','$gamecat','$remoteurl','$champ','$champs','')");
} else {

message("This game is already added, or the idname conflicts with an existing game. Please delete the game, or change the idname to correct the problem.");

}

}


}

?>


<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width='60%' align='center' class='headertableblock' colspan='2'> Adding Game</td><tr>

<form action='' method='POST' enctype="multipart/form-data">
<input type='hidden' name='akey' value='<?php echo $key; ?>'>
<tr><td class='arcade1' align='center' colspan='2'><b>Method: <?php echo $_GET['method']; ?></b></td>

<?php
$what="Add";
//
// What method?
//

if ($_GET['method'] == "upload") {
?>
<tr><td class='arcade1' align='left'><b>Game .SWF file:</b></td>
<td class='arcade1' align='center'><input type='file' name='uploadswf'></td></tr>
<tr><td class='arcade1' align='left'><b>Game .GIF file:</b></td>
<td class='arcade1' align='center'><input type='file' name='uploadgif'></td></tr>
<?php
} elseif($_GET['method']== "server") {
?>
<tr><td class='arcade1' align='left'><b>Game .SWF file URL:</b></td>
<td class='arcade1' align='center'><input type='text' name='swf'></td></tr>
<tr><td class='arcade1' align='left'><b>Game .GIF file URL:</b></td>
<td class='arcade1' align='center'><input type='text' name='gif'></td></tr>
<?php
} elseif($_GET['method']== "hotlink") {
?>
<tr><td class='arcade1' align='left'><b>.SWF file URL:</b></td>
<td class='arcade1' align='center'><input type='text' name='swf'></td></tr>
<tr><td class='arcade1' align='left'><b>GIF file:</b></td>
<td class='arcade1' align='center'><input type='file' name='uploadgif'></td></tr>
<?php
} elseif($_GET['method']== "ftp") {
?>
<tr><td class='arcade1' align='left' colspan='2'>The game files have already been uploaded via FTP; now use the form to import or type the details manually.</td></tr>
<?php
} elseif($_GET['method']== "edit") {
$what = "Edit";
$game=htmlspecialchars($_GET['game'], ENT_QUOTES);

$editgame = mysql_fetch_array(run_query("SELECT * FROM phpqa_games WHERE gameid='$game'"));

if ($editgame['remotelink'] != "") {
?>

<tr><td class='arcade1' align='left'><b>.SWF file URL: <a href="javascript:alert('You are hotlinking this game. Hotlinking means to loads a game from a remote server. If you wish to STOP hotlinking from another host rather than use the hosting the arcade is on, delete the url in the box and upload the game yourself.');">[?]</a></b></td>
<td class='arcade1' align='center'><input type='text' name='swf' value='<?php echo $editgame[remotelink]; ?>'></td></tr>

<?php
} else {
?>
<tr><td class='arcade1' align='left'><b>.SWF file Status:</b></td>
<td class='arcade1' align='center'>

<?php
$check = file_exists("./arcade/$game.swf");
if ($check) { 
echo "<font color='green'>OK:</font> The swf file is found on your server."; 
} else {
echo "<font color='red'>BAD:</font> The swf file is not found on your server. Please try reuploading it, or correct the idname.";
}

?>
<tr><td class='arcade1' align='left'><b>.SWF file URL Hotlink? <a href="javascript:alert('Hotlinking means to loads a game from a remote server. If you wish to start hotlinking from another host rather than use the hosting the arcade is on, paste the URL in the box.');">[?]</a></b></td>
<td class='arcade1' align='center'><input type='text' name='swf' value='<?php echo $editgame[remotelink]; ?>'></td></tr>
</td></tr>
<?php
}

}
?>

<?php
if($_GET['method'] != "edit") {
?>
<tr><td class='arcade1' align='center' colspan='2'><b>Attach Importer</b></td>
<tr><td class='arcade1' align='left'><b>Game .PHP file:</b></td>
<td class='arcade1' align='center'><input type='file' name='php'></td></tr>
<?php
}
?>
<tr><td class='arcade1' align='center' colspan='2'><b>or... Enter Game Details</b></td>

<tr>
<td class='arcade1' align='left'><b>Game Name:</b></td>
<td class='arcade1' align='center'><input type='text' name='gamename' value='<?php echo $editgame[game]; ?>'></td></tr>
<tr><td class='arcade1' align='left'><b>Height:</b></td>
<td class='arcade1' align='center'><input type='text' name='height' value='<?php echo $editgame[gameheight]; ?>'></td></tr>
<tr><td class='arcade1' align='left'><b>Width:</b></td>
<td class='arcade1' align='center'><input type='text' name='width' value='<?php echo $editgame[gamewidth]; ?>'></td></tr>
<tr><td class='arcade1' align='left'><b>Idname:</b></td>
<td class='arcade1' align='center'>

<?php if($editgame[gameid]  == "") { ?>

<input type='text' name='idname' value=''>

<?php } ELSE { 
echo "<input type='hidden' name='idname' value='$editgame[gameid]'> $editgame[gameid]";
} ?>
</td></tr>
<tr><td class='arcade1' align='left'><b>Description:</b></td>
<td class='arcade1' align='center'><input type='text' name='desc' value='<?php echo $editgame[about]; ?>'></td></tr>
 </td>
<tr><td class='arcade1' align='center' colspan='2'><b>Choose A Category</b></td>

<tr><td class='arcade1' align='left'><b>Category Options :</b></td><td class='arcade1' align='center'><select name='gamecat'>
<?php
$catquery=run_query("SELECT * FROM phpqa_cats");
 while ($catlist= mysql_fetch_array($catquery)) {
if( $editgame['gamecat'] == $catlist[0] ) {
echo  "<option value='$catlist[0]' selected='selected'>$catlist[1]</option>";
} else {
echo  "<option value='$catlist[0]'>$catlist[1]</option>";
}

}
?>
</select>

<tr><td class='headertableblock' colspan='2'><div align=center><input type='Submit' name='addgame' value='<?php echo $what; ?> Game'></div></td></tr>

</form>
</table>
</div>
<br>

<?php
}

} elseif($place == "tar_import") {
?>

<?php
$thecat="0";
if($_GET['cat']) $thecat=htmlspecialchars($_GET['cat']);


if($_GET['untar']) {

vsess();

$tarfile=$_GET['untar'];

$tarfile_name=str_replace(".tar", "", $tarfile);
$tarfile_name=str_replace("game_", "", $tarfile_name);


// Untar file
// Function
// By SeanJ.Jcink.com
// untar function 2.0 by Sean

function untar($file,$to){  
if (substr($to,-1)!="/") $to.="/";  
$o=fopen($file,"rb"); if (!$o) return false;  
while(!feof($o)){  
$d=unpack("a100fn/a24/a12size",fread($o,512));  
//print_r($d);  
if (!$d[fn]) break;  
$dir="";  
$e=explode("/",$d[fn]);  
array_pop($e);  
foreach($e as $v) {$dir.=$v."/";@mkdir($to.$dir);}  
$d[size]=octdec(trim($d[size]));  
$o2=fopen($to.$d[fn],"w");  
if(!$o2) return false;  
if ($d[size]) fwrite($o2,fread($o,$d[size]));  
fclose($o2);  
$t=512-($d[size]%512);  
if ($t&&$t!=512) fread($o,$t);  
}  
fclose($o);  
return true;  
}


// untar ALL the crap
untar("./tars/$tarfile", "./tars/");

@rename("./tars/$tarfile_name.swf","./arcade/$tarfile_name.swf");
@rename("./tars/{$tarfile_name}1.gif","./arcade/pics/{$tarfile_name}.gif");

@unlink("./tars/{$tarfile_name}2.gif");

if(file_exists("./tars/$tarfile_name.php")) {

require("./tars/$tarfile_name.php");

} else {

message("The tar file is corrupted or invalid, and the game cannot be added, sorry.");

}

if(file_exists("./tars/gamedata/$tarfile_name/$tarfile_name.txt")) {
@mkdir("./arcade/gamedata/$tarfile_name", 0777);

@rename("./tars/gamedata/{$tarfile_name}/$tarfile_name.txt","./arcade/gamedata/{$tarfile_name}/$tarfile_name.txt");

@unlink("./tars/gamedata/$tarfile_name/v3game.txt");

@unlink("./tars/gamedata/$tarfile_name/v32game.txt");

@unlink("./tars/gamedata/$tarfile_name/index.html");

@rmdir("./tars/gamedata/$tarfile_name/");

@rmdir("./tars/gamedata/");
}


@unlink("./tars/{$tarfile_name}.php");


$gamename = $config['gtitle'];
$about = htmlspecialchars($config['gwords'], ENT_QUOTES);
$gameheight = $config['gheight'];
$gamewidth = $config['gwidth'];
$idname = $config['gname'];

$idname = htmlspecialchars($idname, ENT_QUOTES);
$addedalready = mysql_fetch_array(run_query("SELECT * FROM phpqa_games WHERE gameid='$idname'"));


if (!$addedalready) {
if($idname !="") {
run_query("INSERT INTO phpqa_games (game,gameid,gameheight,gamewidth,about,gamecat,remotelink,Champion_name,Champion_score,times_played) VALUES ('$gamename','$idname','$gameheight','$gamewidth','$about','$thecat','$remoteurl','$champ','$champs','')");
}
} else {

}



}
?>


<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width='60%' align='center' class='headertableblock' colspan='2'> Adding Game</td><tr>

<?php
if ($handle = opendir('./tars/')) {
   while (false !== ($file = readdir($handle))) { 
       if ($file != "." && $file != "..") {

$tarfile_name=str_replace(".tar", "", $file);
$idname=str_replace("game_", "", $tarfile_name);

       $addedalready = mysql_fetch_array(run_query("SELECT * FROM phpqa_games WHERE gameid='$idname'"));

?>
<tr><td class='arcade1' align='center'><?php echo $file; ?></td><td class='arcade1' align='center'>[ <?php if(!$addedalready) { ?><a href='?cparea=tar_import&untar=<?php echo $file; ?>&cat=<?php echo $thecat; ?>&akey=<?php echo $key; ?>'>Install</a> <?php }  else { echo "Added"; } ?> | <a href='?cparea=tar_import&untar=<?php echo $file; ?>&cat=<?php echo $thecat; ?>&akey=<?php echo $key; ?>'>Reupload</a> ]</td></tr>
 <?php
	   
       } 
   }
   closedir($handle); 
}
?>


<tr><td class='arcade1' align='center' colspan='2'><b>Choose A Category</b></td>

<form action='' method='GET' enctype="multipart/form-data">

<tr><td class='arcade1' align='left'><b>Category Option:</b></td><td class='arcade1' align='center'><select name='cat'>
<?php
$catquery=run_query("SELECT * FROM phpqa_cats");
 while ($catlist= mysql_fetch_array($catquery)) {
if( $_GET['cat'] == $catlist[0] ) {
echo  "<option value='$catlist[0]' selected='selected'>$catlist[1]</option>";
} else {
echo  "<option value='$catlist[0]'>$catlist[1]</option>";
}

}
?>
</select>

<tr><td class='headertableblock' colspan='2'><div align=center><input type='hidden' name='cparea' value='tar_import'><input type='Submit' name='addgame' value='Switch Category'></div></td></tr>

</form>
</table>
</div>
<br />
<?php



} elseif($place == "skin") {

if ($_GET['skinremove']) {
vsess();
if ($_GET['skinremove'] == "Default.css") {
message("You cannot remove the default skin.");
} else {
@unlink("./skins/".$_GET['skinremove']);
}

}
?>
<div align='center'>
<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=60% align=center class=headertableblock>Skin Name</td><td width=10% align=center class=headertableblock>Delete</td><td width=60% align=center class=headertableblock>Modify</td><td align='center' class='headertableblock'>Preview</td><tr>

<?php 
if ($_POST['addcssfile']) {
	vsess();
$fp = fopen("./skins/".$_POST['skincssfilename'].".css","w+");
}
?>

<div align=center><?php
if ($handle = opendir('./skins/')) {
   while (false !== ($file = readdir($handle))) { 
       if ($file != "." && $file != "..") {
if (!is_dir("./skins/$file")) {
           echo "<td class=arcade1>$file</td><td class=arcade1><a href='Arcade.php?cparea=skin&skinremove=$file&akey=$key'><div align=center>[X]</div></a></td><td class=arcade1 align='center'><a href='Arcade.php?skin=$file&cparea=editor'>[Edit CSS]</a></td><td class='arcade1'><a href='javascript:document.getElementsByTagName(\"link\")[0].href=\"skins/$file\";void(0);'>[Preview]</a></td></tr>"; 
}
       } 
   }
   closedir($handle); 
}?></table></div><br>

<div align='center'><div class='tableborder'><table width=100%% cellpadding='5' cellspacing='1'><tr><td class=headertableblock colspan=9><b><font size=-5>Make new CSS File</font></b></td></tr><td width=50%% align=center class=arcade1><font size=-5>New CSS File name (leave out .css)</font></td><td width=10% align=center class=arcade1><font size=-5>Action</font></td></div><tr><td class=arcade1> <form method=post action="?cparea=skin"><input type='hidden' name='akey' value='<?php echo $key; ?>'><div align=center><input type=text name=skincssfilename></center> </div></td><td class=arcade1><div align=center><input type='submit' value='Add' name='addcssfile'></div></td></table></div></form><br />

<?php } ?>
<?php 
if ($place == "editor") { 

$skin=htmlspecialchars($_GET['skin'], ENT_QUOTES);
$skin=str_replace("..","", $skin);

if ($_POST['skinedit']) {

vsess();

// IPB 1.3 skin allowance
$_POST['cssforarcade']=str_replace("maintitle","headertableblock", $_POST['cssforarcade']);
$_POST['cssforarcade']=str_replace("row1","arcade1", $_POST['cssforarcade']);
$acss = @fopen("./skins/$skin","w");
fwrite($acss,stripslashes($_POST['cssforarcade']));
if($acss) { message("Changes written successfully"); } else { message("Changes failed to be written. Please check permissions on your skin files and folder."); }
}

$ARCADECSS = @file_get_contents("./skins/$skin");
if($ARCADECSS=="") $ARCADECSS="File not found";

 message("<form method='post' action='?cparea=editor&skin=$skin'><input type='hidden' name='akey' value='$key'><textarea rows='40' cols='60' name='cssforarcade'>$ARCADECSS</textarea><br /><input type='submit' name='skinedit' value='Edit Stylesheet'></form>");

} 
?>
<?php if($place == "games") {
?>
<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1' align='center'>Sort: 

<?php
echo "<br /><br />";
$catquery=run_query("SELECT * FROM phpqa_cats");
 while ($catlist= mysql_fetch_array($catquery)) {
echo  "[ <a href='?cparea=games&cat=$catlist[0]'>$catlist[1]</a> ]";
} 

?> 

<a href='?cparea=games&showall=1'>Show All</a> &middot; <a href='?cparea=games&hotlink=1'>Check Hotlinked</a><br /><br />
<form action='' method='GET'><input type='hidden' name='cparea' value='games'><input type='text' name='search' value=''><input type='Submit' value='Search'></form>
</td></tr></table></div><br />

<form action='' method='POST'>
<input type='hidden' name='akey' value='<?php echo $key; ?>'>
<?php
$gselect = $_POST['gselect'];
$dowhat = htmlspecialchars($_POST['dowhat'], ENT_QUOTES);

	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//		  Admin Actions
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if (!is_numeric($dowhat)) {

if ($dowhat == "deletegame") {
vsess();
for($x=0;$x<=count($gselect)-1;$x++){
@unlink("./arcade/$gselect[$x].swf");
@unlink("./arcade/pics/$gselect[$x].gif");
$f=htmlspecialchars($gselect[$x], ENT_QUOTES);
run_query("DELETE FROM phpqa_games WHERE gameid='$f'");
}
}

if ($dowhat == "clearscores") {
vsess();
for($x=0;$x<=count($gselect)-1;$x++){
$f=htmlspecialchars($gselect[$x], ENT_QUOTES);
run_query("DELETE FROM phpqa_scores WHERE gameidname = '$f'");
run_query("DELETE FROM phpqa_leaderboard WHERE gamename = '$f'");
run_query("UPDATE `phpqa_games` SET `Champion_name` = '' WHERE gameid='$f'");
run_query("UPDATE `phpqa_games` SET `Champion_score` = '' WHERE gameid='$f'");
}
}

} else {
vsess();
for($x=0;$x<=count($gselect)-1;$x++){
$f=htmlspecialchars($gselect[$x], ENT_QUOTES);
run_query("UPDATE `phpqa_games` SET `gamecat` = '$dowhat' WHERE gameid='$f'");
}

}
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	//		  Game index display
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$choice = htmlspecialchars($_GET['cat'], ENT_QUOTES);
if ($_GET['cat']) {

if(is_numeric($_GET['cat']))$glist = run_query("SELECT gameid,game,about,gamecat,Champion_name,Champion_score FROM phpqa_games WHERE gamecat ='$choice' ORDER BY id DESC");

} elseif($_GET['search']) {

$search=htmlspecialchars($_GET['search'], ENT_QUOTES);
$glist = run_query("SELECT gameid,game,about,gamecat,Champion_name,Champion_score from phpqa_games WHERE game like \"%$search%\"  
  order by id");

} elseif($_GET['showall']) {

	$glist = run_query("SELECT gameid,game,about,gamecat,remotelink,Champion_name,Champion_score FROM phpqa_games ORDER BY id DESC");

} elseif($_GET['hotlink']) {

	$glist = run_query("SELECT gameid,game,about,gamecat,remotelink,Champion_name,Champion_score FROM phpqa_games ORDER BY id DESC");

} else {

	$glist = run_query("SELECT gameid,game,about,gamecat,remotelink,Champion_name,Champion_score FROM phpqa_games ORDER BY id DESC LIMIT 0,10");

}


// games function


function displaygames() {

global $g;

if ($g[Champion_score]==""){
$g[Champion_score] = "------------";
}

if ($g[Champion_name]==""){
$g[Champion_name] = "--------";
}

	$cname = mysql_fetch_array(run_query("SELECT * FROM phpqa_cats WHERE id ='$g[3]'"));
	echo "<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1' class='gameview'><tr><td width='5%' align='center' class='headertableblock'></td><td width='60%' align='center' class='headertableblock'>$g[1]</td><td width='20%' align='center' class='headertableblock'>Top Score</td><td width='15%' align='center' class='headertableblock'>In Category: </td><td width='2%' align='center' class='headertableblock'></td></tr><tr><td class='arcade1' valign='top' align='center'>
<a href='Arcade.php?play=$g[0]'><img height='50' width='50' alt='$g[0]' border='0' src='arcade/pics/$g[0].gif' /></a><br /></td><td class='arcade1'  align='center'>$g[2]<br /><br /><a href='Arcade.php?play=$g[0]'>[Play]</a> <a href='?cparea=addgames&method=edit&game=$g[0]'>[Edit Game]</a></td><td class='arcade1' valign='top' align='center'><img alt='image' src='skins/Default/crown1.gif' /><br /><b>$g[Champion_score]</b><br /><a href='Arcade.php?action=profile&amp;user=$g[Champion_name]'>$g[Champion_name]</a><br /><a href='Arcade.php?id=$g[0]'>View Highscores</a></td><td class='arcade1' valign='top' align='center'><a href='Arcade.php?cparea=games&cat=$g[3]'>$cname[cat]</a></td><td class='arcade1' valign='top' align='center'><input type='checkbox' name=gselect[] value='$g[0]'></td></tr></table></div><br />";

}

// games function


	while($g=mysql_fetch_array($glist)){ 	
	// Select from the scores table....

if ($_GET['hotlink']) {

if ($g[remotelink] != "") {

$quickcheck = @fopen("$g[remotelink]", "r");
if ($quickcheck) {
echo "<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'>Link check: <a href='$g[remotelink]'>$g[remotelink]</a> (<b><font color='green'>ONLINE</font></b>)</td></tr></table></div>";
} else {
echo "<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'>Link check <b><font color='red'>DOWN</font></b></td></tr></table></div>";
}
echo "<br />";

displaygames();

}


} else {

displaygames();

}


}

?>
<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'>
Move to/Perform:<select size="1" name="dowhat">
<optgroup label="Preform Action on Game(s):">
<option value='clearscores'>Clear Scores</option>
<option value='deletegame'>Delete</option>
<optgroup label="Place Game(s) In Category:">

<?php
$catquery=run_query("SELECT * FROM phpqa_cats");
 while ($catlist= mysql_fetch_array($catquery)) {

echo  "<option value='$catlist[0]'>$catlist[1]</option>";
} 
?>

</select>

<input type='Submit' value='Go'>
</td><td width='1px' class='arcade1'><input type='checkbox' onclick="c=document.getElementsByTagName('input');for(x=0;x<c.length;x++) if (c[x].type.toLowerCase()=='checkbox') c[x].checked=this.checked"></td></tr></table></div><br /></form>
<?php

	}
?>

<?php if ($place == emotes) { ?>
<?php
$remove=$_GET['remove'];
if ($_GET['remove']) {
$file = "emotes_faces.txt";
$array=file($file); 
$file2=fopen($file, "w"); 
foreach($array as $k=>$v){ 
if ($k == $remove || $v == "" ){ 
continue; 
} 
fwrite($file2, $v); 
} 
fclose($file2); 

$file = "emotes_pics.txt";
$array=file($file); 
$file2=fopen($file, "w"); 
foreach($array as $k=>$v){ 
if ($k == $remove || $v == "" ){ 
continue; 
} 
fwrite($file2, $v); 
} 
fclose($file2);

}

$face = $_POST['face'];
$pic = $_POST['pic'];
if ($_POST['face']) {
vsess();
$smilefile = fopen("emotes_faces.txt", "a");
fwrite($smilefile,  "$face\n" );

$imagefile = fopen("emotes_pics.txt", "a");
fwrite($imagefile,  "$pic\n" );
}


$smilies = file("emotes_faces.txt");
$smiliesp = file("emotes_pics.txt");
?>

<br>

<?php

echo "<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=60% align=center class=headertableblock>Face</td><td width=10% align=center class=headertableblock>Preview</td><td width=60% align=center class=headertableblock>Remove</td>";

	// display
for($x=1;$x<count($smilies);$x++) {

echo "<tr><td class=arcade1>$smilies[$x]</td><td class=arcade1><div align=center><img src='emoticons/$smiliesp[$x]'></div></td><td class=arcade1><a href='?cparea=emotes&remove=$x'>Remove</a></td></tr>";

}

echo "</table></div>";
?>
<form action='Arcade.php?cparea=emotes' method='POST'>
<input type='hidden' name='akey' value='<?php echo $key; ?>'>
<br />
<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=60% align=center class=headertableblock>Add Emoticon</td><tr><td class=arcade1>
<div align=center>Face/action:<input type=text name=face>
Image: 

	    <select name="pic">
<?php
echo "<option value=':)' selected>Select an image</option>";

$dir = "./emoticons/";
   if ($dh = opendir($dir)) {
       while (($file = readdir($dh)) !== false) {
 if ($file == "." || $file == "..") continue;
echo "<option value='$file'>$file</option>";
       }
       closedir($dh);
   }
?>
</select>
<input type='Submit' name='Submit' value='Add Emoticon'></div>
</td></tr></table></div>
</form>



<?php } ?>

<?php if ($place == mysql) {
$thequery=$_POST['thequery'];
if($_POST['querymysql'] == "Run Query") {
	vsess();
$goquery=run_query($thequery);
}

?>
<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='center' colspan=9><b>Query</b></td></tr><td class='arcade1' align='center'><form action='' method='POST'>
<input type='hidden' name='akey' value='<?php echo $key; ?>'>
<textarea cols=40 rows=2 wrap='OFF' name='thequery'></textarea><br />
<input type='Submit' name='querymysql' value='Run Query'>
<br />
<?php
if($_POST['querymysql']) {
if($goquery) { echo "Query Executed Successfully"; } else { echo "Query failed."; 
echo mysql_error();
}
}
?>
</td></table></div><br />

<form action='' method='POST'>
<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width='60%' align='center' class='headertableblock' colspan='2'>MySQL Database Manager</td>
<?php
$dbs = array('phpqa_accounts','phpqa_cats','phpqa_games','phpqa_leaderboard','phpqa_scores','phpqa_shoutbox');
foreach ($dbs as $k=>$v){
echo "<tr><td class='arcade1' align='left'><b>$v</b></td><td class='arcade1' align='left' width='1%'><b><input type='checkbox' name='$v' value='$v'></b></td></tr>";
}
?>
<tr><td class='arcade1' align='center' colspan='2'><b>Action:</b> <select size="1" name="dowhat">
<option value='optimize'>Optimize</option><option value='repair'>Repair</option><option value='check'>Check</option><option value='dump'>View Dump</option></td></tr>

<tr><td class='headertableblock' colspan='2'><div align=center><input type='Submit' name='runsql' value='Run'></div></td></tr>
</table>
</div>
<br />
</form>

<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='center' colspan=9><b>Full Backup</b></td></tr><td class='arcade1' align='center'><form action='' method='POST'>
<?php
foreach ($dbs as $k=>$v){
echo "<input type='hidden' name='$v' value='a'>";
}
?>
<input type='hidden' name='dowhat' value='dump'><input type='Submit' name='' value='Generate Complete Database Backup'>
</td></table></div><br />

<?php
$dowhat = $_POST['dowhat'];
$tablearray = $_POST['dbselect'];

print_r($tablearray);

if ($_POST['dowhat'] == dump||$_GET['dowhat']=="downloaddump") {
?>
<div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1'><tr><td class='headertableblock' align='center' colspan=9><b>SQL (dump) Backup</b></td></tr><td class='arcade1' align='center'><br />Below is a copy of your arcade table(s) that can be imported onto your hosts PhpMYadmin. To keep this backup, <b>copy</b> the entire text in the area below into a notepad file and save it, or <a href='?cparea=mysql&amp;dowhat=downloaddump'>download</a> it.
<?php
echo "<textarea cols=100 rows=50 wrap='OFF'>";
if ($_GET['dowhat']=="downloaddump") {
header("Content-type:text/plain");
header("Content-disposition:attachment;filename=\"phpqa_mysql_dump.sql\"");
ob_clean();
}
$q=run_query("SHOW TABLES LIKE 'phpqa_%'");
while($s=mysql_fetch_array($q)) $tables[]=$s[0];
foreach($tables as $v){
$q=mysql_fetch_array(run_query("SHOW CREATE TABLE $v"));
echo "\n\n--$v's Table Structure:\n".$q[1]."\n\n";
$q=run_query("SELECT * FROM $v");
echo "--$v's Dump:\n";
while($r=mysql_fetch_assoc($q)) echo "INSERT INTO $v(`".implode("`,`",array_keys($r))."`) VALUES ('".implode("','",$r)."')\n";
}
if ($_GET['dowhat']=="downloaddump") die();
echo "</textarea></td></table></div><br />";
} elseif($dowhat=="optimize") {

foreach ($dbs as $k=>$v){
if ($_POST[$v]) {
$optcheck = mysql_fetch_array(run_query("OPTIMIZE TABLE `$v`"));
if ($optcheck) { message("Table <b>$v</b> optimized. Status: $optcheck[Msg_text]"); } else { message("Table <b>$v</b> failed to be optimized. Try repairing it. $optcheck[Msg_text]"); }
}
}


} elseif($dowhat=="repair") {

foreach ($dbs as $k=>$v){
if ($_POST[$v]) {
$optcheck = mysql_fetch_array(run_query("REPAIR TABLE `$v`"));
if ($optcheck) { message("Table <b>$v</b> Repaired. Status: $optcheck[Msg_text]"); } else { message("Table <b>$v</b> failed to be repaired."); }
}
}

} elseif($dowhat=="check") {

foreach ($dbs as $k=>$v){
if ($_POST[$v]) {
$optcheck = mysql_fetch_array(run_query("CHECK TABLE `$v`"));
if ($optcheck) { message("Table <b>$v</b> Checked. Status: $optcheck[Msg_text]"); } else { message("Table <b>$v</b> failed to be checked."); }
}
}

}
?>

<?php } elseif($place=="members") {

message("View Only: <br /><a href='?cparea=members&act=Admin'>Admins</a> &middot; <a href='?cparea=members&act=Moderator'>Moderators</a> &middot; <a href='?cparea=members&act=Member'>Members</a> &middot; <a href='?cparea=members&act=Banned'>Banned</a> &middot; <a href='?cparea=members&act=Validating'>Validating</a>");


if($_POST['members_selected']) {
vsess();
$gselect=$_POST['members_selected'];
for($x=0;$x<=count($gselect)-1;$x++){
$f=htmlspecialchars($gselect[$x], ENT_QUOTES);
run_query("DELETE FROM `phpqa_scores` WHERE username='$f'");
run_query("DELETE FROM `phpqa_leaderboard` WHERE username='$f'");
run_query("DELETE FROM `phpqa_accounts` WHERE name='$f'");
run_query("UPDATE `phpqa_games` SET `Champion_score` = '' WHERE Champion_name='$f'");
run_query("UPDATE `phpqa_games` SET `Champion_name` = '' WHERE Champion_name='$f'");
run_query("DELETE FROM `phpqa_leaderboard` WHERE username='$f'");
}
}

/* ################## Start of change name ################## */

$n=htmlspecialchars($_GET['change'], ENT_QUOTES);
if ($_GET['change']) {
	vsess();
$new_name=htmlspecialchars($_POST['new_name'], ENT_QUOTES);
$checkexistance = mysql_fetch_array(run_query("SELECT name FROM phpqa_accounts WHERE name = '$new_name'"));
if($checkexistance) { 
message("The name, $new_name is already being used by another person."); 
} else {
run_query("UPDATE `phpqa_games` SET `Champion_name` = '$new_name' WHERE Champion_name='$n'");
run_query("UPDATE `phpqa_leaderboard` SET `username` = '$new_name' WHERE username='$n'");
run_query("UPDATE `phpqa_scores` SET `username` = '$new_name' WHERE username='$n'");
run_query("UPDATE `phpqa_accounts` SET `name` = '$new_name' WHERE name='$n'");
run_query("UPDATE `phpqa_tournaments` SET `user`= '$new_name' WHERE `user`='$n'");
run_query("UPDATE `phpqa_tournaments` SET `winner`='$new_name' WHERE `winner`='$n'");
}
}

if ($_GET['changename']) {
	$_GET['changename']=htmlspecialchars($_GET['changename']);
echo "<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=30% align=center class=headertableblock>Change Name</td><tr><td class=arcade1><div align=center><form action='?cparea=members&change=$_GET[changename]' method='POST'><input type='hidden' name='akey' value='$key'><input type=text name=new_name value=\"$_GET[changename]\"><input type=submit value='Change Name'></form><br /><br />";
echo "</td></tr></table></div><br>";
}

/* ################## end of change name ################## */


/* ########### PASS CHANGE ################ */


if ($_GET['changepass']) {
		$_GET['changepass']=htmlspecialchars($_GET['changepass']);
echo "<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=30% align=center class=headertableblock>Change Password</td><tr><td class=arcade1><div align=center><form action='?cparea=members&changepwd=$_GET[changepass]' method='POST'><input type='hidden' name='akey' value='$key'><input type=text name='new_pass' value=''><br /><input type=submit value='Change Password'></form><br /><br />Enter a new password for $_GET[changepass]";
echo "</td></tr></table></div><br>";
}

$n=htmlspecialchars($_GET['changepwd'], ENT_QUOTES);
$new_pass=md5(sha1($_POST['new_pass']));
if($_GET['changepwd']) { 
vsess();
run_query("UPDATE `phpqa_accounts` SET `pass` = '$new_pass' WHERE name='$n'", 1); 
}

$n=htmlspecialchars($_GET['validate'], ENT_QUOTES);
if($_GET['validate']) { vsess();
	run_query("UPDATE `phpqa_accounts` SET `group` = 'Member' WHERE name='$n'");
}


$a=htmlspecialchars($_GET['deleteav'], ENT_QUOTES);
if($_GET['deleteav']) { 
	vsess();
	run_query("UPDATE `phpqa_accounts` SET `avatar` = '' WHERE name='$a'"); }

$cg=htmlspecialchars($_GET['changegroupgo'], ENT_QUOTES);
$fg=htmlspecialchars($_POST['chosengroup'], ENT_QUOTES);

if($_GET['changegroupgo']) { 
	vsess();
	run_query("UPDATE `phpqa_accounts` SET `group` = '$fg' WHERE name='$cg'"); }


if ($_GET['changegroup']) {
echo "<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=30% align=center class=headertableblock>Change Usergroup of: $_GET[changegroup] </td><tr><td class=arcade1><div align=center><form action='?cparea=members&changegroupgo=".htmlspecialchars($_GET['changegroup'])."' method='POST'><input type='hidden' name='akey' value='$key'>";

?>
About: <a href='javascript:alert("As an admin, a user has FULL control of the arcade. Including the ability to add games, make new admins and moderators, and more. Only make admins you trust, proceed with caution.");'>Admin [?]</a> &middot; <a href='javascript:alert("As a moderator, basic access is given. A user has the ability to delete scores, lookup IP addresses, and IP ban users. They are also able to moderate the shoutbox.");'>Moderator [?]</a> &middot; <a href='javascript:alert("A member is the basic group. They can only use the arcade related features such as playing games and using the shoutbox.");'>Member [?]</a> &middot; <a href='javascript:alert("Validating users are members awaiting manual validation. They are blocked from using any means of communication in the arcade, and submitting their highscores.");'>Validating [?]</a> &middot; <a href='javascript:alert("A banned member no longer has access to the arcade. ");'>Banned [?]</a>


<select name='chosengroup'>
<option value='Admin'>Admin</option>
<option value='Moderator'>Moderator</option>
<option value='Member'>Member</option>
<option value='Validating'>Validating</option>
<option value='Banned'>Banned</option>
</select>

<input type=submit value='Change UserGroup'></form></td></tr></table></div><br>
<?php
}

if(!$_GET['act']) { 
$memberdata=run_query("SELECT * FROM phpqa_accounts"); 
} else {
$picked=htmlspecialchars($_GET['act'], ENT_QUOTES);
$memberdata=run_query("SELECT * FROM phpqa_accounts WHERE `group`='$picked'"); 
}

?>
<form action='' method='POST'>
<?php echo "<input type='hidden' name='akey' value='$key'>"; ?>
<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=30% align=center class=headertableblock>Name</td><td width=70% align=center class=headertableblock>Edit</td><td width=20% align=center class=headertableblock>Email</td><td width=20% align=center class=headertableblock>IP</td><td width=60% align=center class=headertableblock><input type='checkbox' onclick="s=document.getElementsByTagName('input');for(x=0;x<s.length;x++) if (s[x].type=='checkbox') s[x].checked=this.checked" /></td>
<?php
	while($g=mysql_fetch_array($memberdata)){ 
?>
<tr><td class=arcade1 alighn='left'><?php echo $g[1]; ?> (<i><?php echo $g['group']; ?></i>)
</td><td class=arcade1><div align=center><A href='?cparea=members&changegroup=<?php echo $g[1]; ?>'>[ Edit Group ]</a> <A href='?cparea=members&deleteav=<?php echo $g[1]; ?>&akey=<?php echo $key; ?>'>[ Delete Avatar ]</a> <A href='?cparea=members&changepass=<?php echo $g[1]; ?>'>[ Change Pass ]</a><A href='?cparea=members&changename=<?php echo $g[1]; ?>'>[ Change Name ]</a> <?php if($_GET['act']=="Validating") { echo "<A href='?cparea=members&validate=$g[1]&act=Validating&akey=$key'>[ Validate ]</a>"; } ?></div></td><td class=arcade1 align='left'><?php echo $g[email]; ?></td><td class=arcade1><?php echo $g[ipaddress]; ?></td><td class=arcade1><input type='checkbox' name='members_selected[]' value='<?php echo $g[1]; ?>'></td></tr>
<?php } ?>
<tr><td class='headertableblock' colspan='5'><div align=center><input type='Submit' name='deleteaccounts' value='Delete Account(s)'></div></td></tr>
</table></div><br>
</form>

<?php
}
?>
<?php if ($place == bannedIPlist) { 
message("Ban one IP below per line. You can also range ban by only putting part of the IP, e.g. 123.45.67.89 -> 123.45");
?>

<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><tr><td width=30% align=center class=headertableblock>Banned IP addrresses</td></tr><tr><td class='arcade1' align='center'>
<?php
if ($_POST['editban']) {
	vsess();
$ArcadeCSSOpen = fopen("./banned.txt","w");
fputs($ArcadeCSSOpen,htmlspecialchars($_POST['cssforarcade'], ENT_QUOTES));
}
?>


 	<form method=post action="?cparea=bannedIPlist">
	<?php echo "<input type='hidden' name='akey' value='$key'>"; ?>
<textarea rows="40" cols="60" name="cssforarcade">
<?php
// Implode CSS
print (implode("",file("./banned.txt")));
?>
</textarea><br /><input type="submit" value="Edit Banned IPs" name="editban">
	</form></td></tr></table></div><br />

<?php 
} ?>
<?php
/*	
if($place == "Cheating_Attempts") {
message("Here you will find basic cheat attempts. Note: Just because you see a member in the log below does NOT mean that they DID cheat. And also, just because you dont see a member in the list below at all, doesnt mean that they havent cheated in a game. If the \"referer\" box is blank then most likely they were blocked by a firewall. <br /> <br /> Check over the caught referers, if you find one that is a link then most likely the person cheated with the a tool upon that page.");

if($_POST['cheaterase']) {
	vsess();
$f=htmlspecialchars($_POST['cheaterase'], ENT_QUOTES);
run_query("DELETE FROM phpqa_logs WHERE id='$f'");
}


$selectfrom=run_query("SELECT * FROM phpqa_logs WHERE log_type='Cheating' ORDER BY phpdate DESC");

	while($g=mysql_fetch_array($selectfrom)){ 

$parse_stamp = date($datestamp, "$g[5]");

echo "<form action='' method='POST'><input type='hidden' name='akey' value='$key'><div class='tableborder'><table width='100%' cellpadding='5' cellspacing='1' class='highscore'><tr><td width='2%' class='headertableblock' align='center'>Username</td><td width='15%' class='headertableblock' align='center'>Score</td><td width='30%' class='headertableblock' align='center'>Comments</td><td width='30%' class='headertableblock' align='center'>Time &amp; Date</td><td width='20%' class='headertableblock' align='center'>IP Address</td><td width='10%' class='headertableblock' align='center'>ScoreBoard</td><td width='10%' class='headertableblock' align='center'>Referer:</td>";

echo "<tr><td class='arcade1' align='center'><a href='Arcade.php?action=profile&amp;user=$g[1]'>$g[1]</a></td><td class='arcade1' align='center'>$g[2]</td><td class='arcade1' width='40%' align='center'>$g[comment]</td><td class='arcade1' width='20%' align='center'>$parse_stamp</td>";

echo "<td width='20%' class='arcade1' align='center'><a href='?modcparea=IPscan&serv=$g[3]'>$g[3]</a></td><td width='20%' class='arcade1' align='center'><a href='Arcade.php?id=$g[gameidname]'>$g[gameidname]</a></td><td width='20%' class='arcade1' align='center'>$g[cheaturl]</td>";
echo "</tr>";
echo "<tr><td class='headertableblock' colspan='7'><div align=center><input type='hidden' name='cheaterase' value='$g[0]'><input type='Submit' name='del' value='Delete Score'></div></td></tr>";
echo "</table></div><br /></form>";

}
}
*/
?>
<?php if ($place == settings) { ?>
<br />
<form action='?cparea=settings' method=POST>
<form action='' method='POST'>
<?php echo "<input type='hidden' name='akey' value='$key'>"; ?>
<div align='center'>
<div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=60% align=center class=headertableblock>Settings</td><td width=60% align=center class=headertableblock>Current setting</td><tr>
<?php
$collectstuff="<?php\n";
// Questions with a Yes/No answer.

$settingsarray=Array(

'Enable Online List?'=>'enable_onlinelist',
'Enable Tournaments?'=>'enable_tournies',
'Enable Password Recovery?'=>'enable_passrecovery',
'Enable Shoutbox?'=>'enable_shoutbox',
'Use logo at the top of every page? (Logo takes the name of the skin and looks for the image in the arcade images folder if enabled)'=>'enable_logo',
'Allow users to post comments?'=>'allow_comments',
'Display the arcade stats above the shoutbox/Login bar?'=>'show_stats_table',
'Disable New Registrations?'=>'disable_reg',
'Enable Admin Validation of New Members?'=>'enable_validation',
//'Use Cheat Protection? <br /> Note:(Can cause problems for users with firewalls)'=>'use_cheat_protect',
'Override user prefs with admin prefs?'=>'override_userprefs',
'Allow Guests to play? (This means that if someone does not have an account, they can still play, but they cannot submit their score.)'=>'allow_guests',
'Require security code to prevent spambots? (Needs GD library image functions to work. If you see a red x in a box  on the signup after you enable this, your host doesn\'t have GD library, and it won\'t work.)'=>'use_seccode',
'Enable sending email to users if they are top, and the score has been defeated?'=>'email_scores',
'Enable email validation? This ensures the email that a user enters when they sign up is real.'=>'enable_email_validation',

);


foreach($settingsarray as $k=>$v){

$in=htmlspecialchars($_POST[$v], ENT_QUOTES);
$collectstuff.='$settings['.$v.']=\''.$in.'\';'."\n";

echo "<tr><td class='arcade1'><b>$k</b></td><td class='arcade1'>";
echo "<select size='1' name='$v'>";
if (!$settings[$v]) {
echo "<option value='0' selected>No</option>";
echo "<option value='1'>Yes</option>";
} else {
echo "<option value='1' selected>Yes</option>";
echo "<option value='0'>No</option>";
}
echo "<br></td></tr>";
}


// Questions with an input box that need to be typed in

$settingsarray2=Array(
'Arcade name?'=>'arcade_title',
'GMDate() format?'=>'datestamp',
"Time zone: <select class='forminput'><option value='-12' Onclick=\"javascript:document.getElementById('timezone').value='-12';void(0);\">(GMT - 12:00 hours) Enitwetok, Kwajalien</option><option Onclick=\"javascript:document.getElementById('timezone').value='-11';void(0);\">(GMT - 11:00 hours) Midway Island, Samoa</option><option value='-10' Onclick=\"javascript:document.getElementById('timezone').value='-10';void(0);\">(GMT - 10:00 hours) Hawaii</option><option value='-9' Onclick=\"javascript:document.getElementById('timezone').value='-9';void(0);\">(GMT - 9:00 hours) Alaska</option><option value='-8' Onclick=\"javascript:document.getElementById('timezone').value='-8';void(0);\">(GMT - 8:00 hours) Pacific Time (US &amp; Canada)</option><option value='-7' Onclick=\"javascript:document.getElementById('timezone').value='-7';void(0);\">(GMT - 7:00 hours) Mountain Time (US &amp; Canada)</option><option value='-6' Onclick=\"javascript:document.getElementById('timezone').value='-6';void(0);\">(GMT - 6:00 hours) Central Time (US &amp; Canada), Mexico City</option><option value='-5' Onclick=\"javascript:document.getElementById('timezone').value='-5';void(0);\">(GMT - 5:00 hours) Eastern Time (US &amp; Canada), Bogota, Lima, Quito</option><option value='-4' Onclick=\"javascript:document.getElementById('timezone').value='-3';void(0);\">(GMT - 4:00 hours) Atlantic Time (Canada), Caracas, La Paz</option><option value='-3.5'>(GMT - 3:30 hours) Newfoundland</option><option value='-3' Onclick=\"javascript:document.getElementById('timezone').value='-3';void(0);\">(GMT - 3:00 hours) Brazil, Buenos Aires, Georgetown, Falkland Is.</option><option value='-2' Onclick=\"javascript:document.getElementById('timezone').value='-2';void(0);\">(GMT - 2:00 hours) Mid-Atlantic, Ascention Is., St Helena</option><option value='-1' Onclick=\"javascript:document.getElementById('timezone').value='-1';void(0);\">(GMT - 1:00 hours) Azores, Cape Verde Islands</option><option value='0'>(GMT) Casablanca, Dublin, Edinburgh, London, Lisbon, Monrovia</option><option value='1' Onclick=\"javascript:document.getElementById('timezone').value='1';void(0);\">(GMT + 1:00 hours) Berlin, Brussels, Copenhagen, Madrid, Paris, Rome</option><option value='2' Onclick=\"javascript:document.getElementById('timezone').value='2';void(0);\">(GMT + 2:00 hours) Kaliningrad, South Africa, Warsaw</option><option value='3' Onclick=\"javascript:document.getElementById('timezone').value='3';void(0);\">(GMT + 3:00 hours) Baghdad, Riyadh, Moscow, Nairobi</option><option value='3.5'>(GMT + 3:30 hours) Tehran</option><option value='4'>(GMT + 4:00 hours) Abu Dhabi, Baku, Muscat, Tbilisi</option><option value='4.5' Onclick=\"javascript:document.getElementById('timezone').value='4.5';void(0);\">(GMT + 4:30 hours) Kabul</option><option value='5' Onclick=\"javascript:document.getElementById('timezone').value='5';void(0);\">(GMT + 5:00 hours) Ekaterinburg, Islamabad, Karachi, Tashkent</option><option value='5.5' Onclick=\"javascript:document.getElementById('timezone').value='5.5';void(0);\">(GMT + 5:30 hours) Bombay, Calcutta, Madras, New Delhi</option><option value='6' Onclick=\"javascript:document.getElementById('timezone').value='6';void(0);\">(GMT + 6:00 hours) Almaty, Colomba, Dhakra</option><option value='7'>(GMT + 7:00 hours) Bangkok, Hanoi, Jakarta</option><option value='8' Onclick=\"javascript:document.getElementById('timezone').value='8';void(0);\">(GMT + 8:00 hours) Beijing, Hong Kong, Perth, Singapore, Taipei</option><option value='9' Onclick=\"javascript:document.getElementById('timezone').value='9';void(0);\">(GMT + 9:00 hours) Osaka, Sapporo, Seoul, Tokyo, Yakutsk</option><option value='9.5' Onclick=\"javascript:document.getElementById('timezone').value='9.5';void(0);\">(GMT + 9:30 hours) Adelaide, Darwin</option><option value='10' Onclick=\"javascript:document.getElementById('timezone').value='10';void(0);\">(GMT + 10:00 hours) Melbourne, Papua New Guinea, Sydney, Vladivostok</option><option value='11' Onclick=\"javascript:document.getElementById('timezone').value='11';void(0);\">(GMT + 11:00 hours) Magadan, New Caledonia, Solomon Islands</option><option value='12' Onclick=\"javascript:document.getElementById('timezone').value='12';void(0);\">(GMT + 12:00 hours) Auckland, Wellington, Fiji, Marshall Island</option></select>"=>'timezone',
'Online List Duration time?(In Minutes)'=>'online_list_dur',
'Games and shouts to display per page?'=>'num_pages_of',
'Banned E-Mail Addresses? (Separate by commas)'=>'banned_mails',
'Banned Usernames? (Separate by commas)'=>'banned_usernames',
'Maxium size of avatar upload files in bytes? Leave blank to disallow avatar uploads.'=>'upload_av_max_size',

);



foreach($settingsarray2 as $k=>$v){

$in=stripslashes(htmlspecialchars($_POST[$v], ENT_QUOTES));
$collectstuff.='$settings['.$v.']=\''.$in.'\';'."\n";
 
echo "<tr><td class='arcade1'><b>$k</b></td><td class='arcade1'>";

$idstuff='';
if($v=="timezone") $idstuff="id='timezone'";

echo "<input type='text' {$idstuff} name='".htmlspecialchars($v)."' value='$settings[$v]'>";

echo "<br></td></tr>";
}

$collectstuff.="\$host='$host';\n\$username='$username';\n\$password='$password';\n\$mysqldatabase='$mysqldatabase';\n";
$collectstuff.="\n?>";
?>

<tr><td class='headertableblock' colspan='2'><div align=center><input type=submit name=SettingsUpdate value='Update Settings'></div></td></tr>
</table></div><br>

</form>
<br>
<?php 

// Write St00f
if($_POST['SettingsUpdate']) {
vsess();
$imagefile = fopen("arcade_conf.php", "w");
fwrite($imagefile,  $collectstuff);

}

// St00f


} ?>
<?php if ($place == cats) { 

if($_GET['do']=="delete") {
vsess();
if(!is_numeric($_POST['gamecat'])) die ();
run_query("DELETE FROM `phpqa_cats` WHERE id = '$_POST[gamecat]'");

}
?>

<div align='center'><div class='tableborder'><table width=100%% cellpadding='5' cellspacing='1'><tr><td class=headertableblock colspan=9><b><font size=-5>Categories</font></b></td></tr><td class=arcade1 align='center'>

<form action='?cparea=cats&do=delete' method='POST'>
<input type='hidden' name='akey' value='<?php echo $key; ?>'>
Manage game cats below. Note: if you delete a cat, all the games within that cat will not be deleted.<br /> <br />

<select name='gamecat'>
<?php
$newcatname=htmlspecialchars($_POST['newcatname'], ENT_QUOTES);

if($_GET['do']=="create") { 
	vsess();
	run_query("INSERT INTO phpqa_cats (cat) VALUES ('$newcatname')");

}

$catquery=run_query("SELECT * FROM phpqa_cats");
 while ($catlist= mysql_fetch_array($catquery)) {
echo  "<option value='$catlist[0]'>$catlist[1]</option>";
}
?>
</select><input type='submit' name='erase' value='Delete'>
</form>
<br /><br />
<form action='?cparea=cats&do=create' method='POST'>
<input type='hidden' name='akey' value='<?php echo $key; ?>'>
<input type='text' name='newcatname'>
<input type='submit' name='create' value='Add Category'>
</form>
</div></div></td></table></div><br />

<?php } ?>

<?php if($place == "Email") { 

$q=run_query("SELECT `email`,`settings` FROM phpqa_accounts");

while($mailing=mysql_fetch_array($q)) {
$settings=explode("|", $mailing[1]);

if($settings[4] != "No") {
$list.= "$mailing[0], ";
}

}

?>
<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'>

<form action="?cparea=Email" method="post">
<h1>Email List</h1><br />
List of users on your mailing list: <br />

<?php
$hd = $_POST['mailheaders'];
if ($_POST['subject']) {
	vsess();
$members = $_POST['members'];
$mailsub = $_POST['subject'];
$mailbody = $_POST['email_body'];
$headers = "From: $hd\n";
$g=@mail($members,$mailsub,$mailbody,$headers);
if(!$g) echo "<br /> Error: The mail(); command has been disabled by your hosting provider for security reasons. The emails <font color=red>could not be sent</font>. Talk to your hosting provider, or follow the directions on sending the email right from your email client.";
}

?>

<textarea rows="5" cols="60" name="members">
<?php echo $list; ?>
</textarea><br />

<input type='hidden' name='akey' value='<?php echo $key; ?>'>

The above users will be sent an email announcement. If your host does not allow people to send mail with <br /> the form below, you can <b>cut</b> and <b>paste</b> the above box into your email addresses (like AOL.com or Yahoo etc) "Send to" address box.<br /><br /><br />
Type the <b>email you want users to be able to reply to (or not) (ex use noreply@thearcade.tld) :</b> <br />
<input type=text name=mailheaders><br />
Type the <b>subject</b> of the email: <br />
<input type=text name='subject'><br />
Type your <b>message</b> here: <br /><br />
<textarea rows="20" cols="80" name="email_body">
</textarea> <BR />
<input type=submit value=Submit name=post>
</form>
</td></tr></table></div><br />

<?php } ?><?php if ($place == filter) { ?>
<div class='tableborder'>
   <div class='arcade1'><center>
<table width='50%' border='0' cellspacing='0' cellpadding='4'>
<tr><td class='arcade1' width='100%' >
<div class="tableborder" style="padding: 0px;">
<table border="0" cellpadding="1" cellspacing="1" width="100%">
    <tr>
        <td class="arcade1" style="padding: 8px 8px 8px; width: 100%">
<?php
if ($_POST['editban']) {
vsess();
$slash = stripslashes($_POST['cssforarcade']);
$ARCADECSS = "badwords.txt";
$ArcadeCSSOpen = fopen($ARCADECSS,"w") or die ("Error editing.");
fputs($ArcadeCSSOpen,$slash);
fclose($ArcadeCSSOpen) or die ("Error Closing File!");
}
?>

<form method='post' action="?cparea=filter">
<input type='hidden' name='akey' value='<?php echo $key; ?>'>
Add new word filters here. Put one word per line in the textbox below.<br /><br />They are not case sensitive, and the filter is loose. <br /><br />For example, censoring "hell" will also censor "hellhole", "hellish", etc.<br /><br />
<textarea rows="10" cols="40" name="cssforarcade">
<?
// Implode CSS
$ARCADECSS = "badwords.txt";
print (implode("",file($ARCADECSS)));
?>
</textarea><br />
                <br />
	<input type="submit" value="Edit filters" name="editban">
	</form></table></table></div></div><br>

<?php } ?>

