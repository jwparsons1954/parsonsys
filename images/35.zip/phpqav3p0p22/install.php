<?php
function message($info,$title) {
echo "<div align='center'><div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=60% align=center class=headertableblock>$title</td><tr><td class=arcade1 valign=top><div align=center>$info</div></td></table></div><br>";
}
?>
<br />
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/2002/REC-xhtml1-20020801/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title> PHP-Quick-Arcade 3.0 Install Wizard </title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-15" /> 
<link rel='stylesheet' type='text/css' href='./skins/Default.css'>
</head>
<body>
<?php
message("Welcome to the PHP-Quick-Arcade install wizard. This installer will guide you through the rest of the process to get your arcade online.","Welcome");

if(!$_GET['step']) {
message("<DIV ALIGN='LEFT'><font color='".(array_shift(explode(".",phpversion()))<4?"red":"green")."'>- PHP 4 or higher</font><br />- MySQL 4 or higher<br />-UNIX/Win NT OS/FreeBSD</DIV><br /><BR />The above software is needed to install your PHPQA.","System Requirements");

message("Step 1: CHMOD 777 your:<br /> arcade_conf.php<br />/arcade/ folder <br /> /pics/ folder.<br />emote_faces.txt and emote_pics.txt","Install Start...");

echo "<div align='center'><div class='tableborder'><table width=100% cellpadding='4' cellspacing='1'><td width=60% align=center class=headertableblock>Permissions check</td><tr><td class=arcade1 valign=top><div align=center>";

$files=Array('skins/BlackDefault.css','skins/GrayDefault.css','skins/Default.css','skins/','arcade_conf.php','emotes_faces.txt','emotes_pics.txt','arcade','arcade/pics','arcade/gamedata');


if ($_SERVER['WINDIR']) {

echo "Windows NT<sup>TM</sup> was detected. CHMOD is not necessary, proceed to install.";

} else {

foreach ($files as $k=>$v){
$g=substr(sprintf("%o",fileperms("./$v")),-3);
if($g == 777) { 
echo "Chmod check <font color=green>OK</font> on <font color=blue>$v</font><br />"; 
} else {
echo "Chmod check<font color=red>FAILED</font> on <font color=blue>$v</font><br />";
$failure=1; 
}

}

}

if(!$failure)  { echo "<br /><br /><a href='install.php?step=2'>Proceed.</a>"; } else {
echo "The check has failed. If you know the files are chmodded, please proceeed. if not, you MUST chmod them.<br /><br />"; 

echo "<a href='install.php?step=2'>Proceed anyway...</a>";
}
echo"</div></td></table></div><br>";

} elseif($_GET['step'] == 2) {
message("Enter your MySQL database details below. They will be tested; then written to the config file.", "Database Check");
if($_POST['mysql_dbuser']) {

$connection = @mysql_connect($_POST['mysql_host'],$_POST['mysql_dbuser'],$_POST['mysql_dbpass']);

if(!$connection) {
message("Unable to establish a connection to your database. 
Please check your details and try again.","Error");
$problem=1;
}

$selection = @mysql_select_db($_POST['mysql_dbname']);

if(!$selection) {
$problem=1;
message("The database <b>name</b> you entered does not exist, please try again.","Error");
}

if(!$problem) {

// start tables

mysql_query("CREATE TABLE `phpqa_accounts` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `pass` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `ipaddress` varchar(255) NOT NULL default '',
  `avatar` varchar(255) NOT NULL default '',
  `group` varchar(255) NOT NULL default '',
  `skin` varchar(255) NOT NULL default '',
  `settings` varchar(50) NOT NULL default '',
  `tournaments` int(11) default '0',
  UNIQUE KEY `id` (`id`),
  KEY `settings` (`settings`)
)");



mysql_query("CREATE TABLE `phpqa_cats` (
  `id` int(11) NOT NULL auto_increment,
  `cat` varchar(15) default NULL,
  UNIQUE KEY `id` (`id`)
)");

mysql_query("CREATE TABLE `phpqa_games` (
  `id` int(11) NOT NULL auto_increment,
  `game` varchar(255) default NULL,
  `gameid` varchar(255) NOT NULL default '',
  `gameheight` smallint(3) NOT NULL default '0',
  `gamewidth` smallint(3) NOT NULL default '0',
  `about` varchar(255) NOT NULL default '',
  `gamecat` varchar(255) NOT NULL default '',
  `remotelink` varchar(255) NOT NULL default '',
  `Champion_name` varchar(255) NOT NULL default '',
  `Champion_score` decimal(20,0) default NULL,
  `times_played` int(11) default '0',
  UNIQUE KEY `id` (`id`),
  KEY `gamecat` (`gamecat`),
  KEY `gameid` (`gameid`)
)");



mysql_query("CREATE TABLE `phpqa_leaderboard` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL default '',
  `thescore` decimal(20,0) default NULL,
  `gamename` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `username` (`username`),
  KEY `username_2` (`username`)
)");


mysql_query("CREATE TABLE `phpqa_logs` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL default '',
  `thescore` decimal(20,0) default NULL,
  `ip` varchar(255) NOT NULL default '0',
  `comment` varchar(255) NOT NULL default '',
  `phpdate` int(10) NOT NULL default '0',
  `gameidname` varchar(255) NOT NULL default '',
  `cheaturl` varchar(255) NOT NULL default '',
  `log_type` text,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `username` (`username`),
  KEY `gameidname` (`gameidname`)
)");


mysql_query("CREATE TABLE `phpqa_scores` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL default '',
  `thescore` decimal(20,0) default NULL,
  `ip` varchar(255) NOT NULL default '0',
  `comment` varchar(255) NOT NULL default '',
  `phpdate` int(10) NOT NULL default '0',
  `gameidname` varchar(255) NOT NULL default '',
  `gamename` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `username` (`username`),
  KEY `gameidname` (`gameidname`)
)");


mysql_query("CREATE TABLE `phpqa_sessions` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `time` varchar(255) NOT NULL default '',
  `location` varchar(255) NOT NULL default '',
  UNIQUE KEY `id` (`id`)
)");


mysql_query("CREATE TABLE `phpqa_shoutbox` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `shout` mediumtext NOT NULL,
  `ipa` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
)");


mysql_query("CREATE TABLE `phpqa_tournaments` (
  `id` int(11) NOT NULL auto_increment,
  `tournament_id` int(11) default NULL,
  `user` text,
  `players` int(11) default NULL,
  `level` int(11) default '0',
  `average_score` text,
  `times_played` int(11) default '0',
  `game_id` text,
  `winner` text,
  `misc_settings` text,
  PRIMARY KEY  (`id`)
)");

message("Install to the database was <font color='green'>SUCCESSFULL!</font>","Database Install Complete");


mysql_query("INSERT INTO `phpqa_games` VALUES (1, 'Hexxagon', 'Hexxagon', '346', '388', 'Overtake the computers jewels.', '', '', '', '', '0');");

mysql_query("INSERT INTO `phpqa_games` VALUES (2, 'Tetris', 'Tetris', '381', '400', 'Make rows of blocks but dont overload the screen.', '', '', '', '', '0');");

mysql_query("INSERT INTO `phpqa_games` VALUES (3, 'Flasteroids', 'Flasteroids', '500', '350', 'A twist on the game asteroids, created by Bodekaer.', '', '', '', '', '0');");


mysql_query("INSERT INTO `phpqa_games` VALUES (4, 'Snake', 'Snake', '319', '359', 'Snake... Just like on your cellphone.', '', '', '', '', '0');");


mysql_query("INSERT INTO `phpqa_games` VALUES (5, 'Simon', 'Simon', '400', '400', 'Test your memmory.', '', '', '', '', '0');");

mysql_query("INSERT INTO `phpqa_games` VALUES (6, 'Asteroids', 'Asteroids', '394', '499', 'The hit arcade classic.', '', '', '', '', '0');");

mysql_query("INSERT INTO `phpqa_games` VALUES (7, 'Space Invaders', 'Invaders', '429', '500', 'Blast Aliens in this classic game!', '', '', '', '', '0');");

mysql_query("INSERT INTO `phpqa_accounts` VALUES ('1','Admin','0c7540eb7e65b553ec1ba6b20de79608','admin@localhost','{$_SERVER['REMOTE_ADDR']}','','Admin','Default','','');");

// Added in 3.0.20
mysql_query("ALTER TABLE `phpqa_accounts` DROP INDEX `settings`");
mysql_query("ALTER TABLE `phpqa_accounts` CHANGE `settings` `settings` LONGTEXT CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ");


// end tables


// Writing to the conf.
$conf=@fopen("arcade_conf.php", "w");

$goforit = @fwrite($conf,"<?php\n\$settings[enable_onlinelist]='1';\n\$settings[enable_tournies]='1';\n\$settings[enable_passrecovery]='1';\n\$settings[enable_shoutbox]='1';\n\$settings[enable_logo]='0';\n\$settings[allow_comments]='1';\n\$settings[show_stats_table]='1';\n\$settings[disable_reg]='0';\n\$settings[enable_validation]='0';\n\$settings[use_cheat_protect]='0';\n\$settings[upload_av_max_size]='0';\n\$settings[use_seccode]='1';\n\$settings[allow_guests]='1';\n\$settings[override_userprefs]='0';\n\$settings[arcade_title]='PHP-Quick-Arcade version 3.0';\n\$settings[datestamp]='jS F Y - h:i A';\n\$settings[online_list_dur]='60';\n\$settings[timezone]='-5';\n\$settings[num_pages_of]='10';\n\$host='$_POST[mysql_host]';\n\$username='$_POST[mysql_dbuser]';\n\$password='$_POST[mysql_dbpass]';\n\$mysqldatabase='$_POST[mysql_dbname]';\n?>");

if(!$goforit) { 
message("arcade_conf.php could not be opened for writing. Please check the permissions.","Failed to write to conf");
}else{
message("Your new arcade is installed! Congratulations! <a href='index.php'>Click here to get started</a>. <br /><br /><br /><font color='red'>Login with the name: <u>admin</u> and password of: <u>admin</u>. <i>Change this password</i> when you login! You may also change your name if you like.</font><br /><br /><H1>DELETE THIS INSTALL.PHP NOW</H1>","Complete");
}

}


}


?>

<form action='?step=2' method='POST'>
<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><td width='60%' align='center' class='headertableblock'>Database Details</td><td width='60%' align='center' class='headertableblock'></td><tr>

 <tr><td class="arcade1" align="left"><b>Enter your database host:</b><br /></td><td class="arcade1" align="left"><input type='text' name='mysql_host' value ='localhost' /></td></tr><tr><td class="arcade1" align="left"><b>Enter your database name:</b></td><td class="arcade1" align="left"><input type="text" name="mysql_dbname" value="" /></td></tr><tr><td class="arcade1"><b>Enter your MySQL Username:</b></td><td class="arcade1"><input type="text" name="mysql_dbuser" value="" /></td></tr><tr><td class="arcade1" align="left"><b>Password:</b></td><td class="arcade1" align="left"><input type="password" name="mysql_dbpass" value="" /></td></tr></div></td>

<tr><td class=headertableblock colspan='2'><div align='center'><input type='submit' name='post' value='Install to Database' /></div></td></tr>


</table></div>
<br />
</form>


<?php
}
?>
<div class='tableborder'><table width='100%' cellpadding='4' cellspacing='1'><tr><td class='arcade1'><?php echo date("md")=="0401"?"Gilligans Arcade":"PHP-Quick-Arcade 3.0"; ?> &copy; Jcink.com</td><td class='arcade1'></td></tr></table></div></div><br />
</body>
</html>
