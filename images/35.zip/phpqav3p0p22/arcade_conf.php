<?php
$notinstalled=1;
?>